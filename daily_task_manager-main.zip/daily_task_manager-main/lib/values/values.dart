library values;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

part 'sizes.dart';
part 'gradients.dart';
part 'colors.dart';
part 'borders.dart';
part 'strings.dart';
part 'images.dart';
part 'styles.dart';
