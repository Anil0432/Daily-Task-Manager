part of values;

class ImagePath {
  //images route
  static const String imageDir = "assets/images";
  static const String screenshotsDir = "assets/screenshots";
  //Images
  // static const String GYM = "$imageDir/gym.jpg";

  //Icons
  static const String GOOGLE_LOGO = "$imageDir/google.png";
}
